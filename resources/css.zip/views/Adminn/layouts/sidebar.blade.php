  <!-- ========== Left Sidebar Start ========== -->
    <div class="vertical-menu">
    <div data-simplebar class="h-100">
      <!--- Sidemenu -->
        <div id="sidebar-menu">
        <!-- Left Menu Start -->
        <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li><li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="bx bx-home-circle"></i>
        <span key="t-dashboards">CategoryBox</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
        <li><a href="category" key="t-default">category</a></li>
        <li><a href="{{ url('admin/banner') }}" key="t-saas">banner</a></li>
        <li><a href="{{ url('admin/artical') }}" key="t-crypto">Artical</a></li>
        <li><a href="dashboard-blog.html" key="t-blog">Blog</a></li>
        <li><a href="dashboard-job.html"><span class="badge rounded-pill text-bg-success float-end" key="t-new">New</span> <span key="t-jobs">Jobs</span></a></li>
        </ul>
        </li>

        <li>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-layout"></i>
                <span key="t-layouts">Layouts</span>
            </a>
            <ul class="sub-menu" aria-expanded="true">
                <li>
            <a href="javascript: void(0);" class="has-arrow" key="t-vertical">Vertical</a>
             <ul class="sub-menu" aria-expanded="true">
                <li><a href="layouts-light-sidebar.html" key="t-light-sidebar">Light Sidebar</a></li>
                <li><a href="layouts-compact-sidebar.html" key="t-compact-sidebar">Compact Sidebar</a></li>
                <li><a href="layouts-icon-sidebar.html" key="t-icon-sidebar">Icon Sidebar</a></li>
                <li><a href="layouts-boxed.html" key="t-boxed-width">Boxed Width</a></li>
                <li><a href="layouts-preloader.html" key="t-preloader">Preloader</a></li>
                <li><a href="layouts-colored-sidebar.html" key="t-colored-sidebar">Colored Sidebar</a></li>
                <li><a href="layouts-scrollable.html" key="t-scrollable">Scrollable</a></li>
            </ul>
        </li>

                                    
        </ul>
        </li>

                        </ul>
                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->
