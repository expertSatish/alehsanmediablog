@extends('frontend.includes.main')

@section('content')
    <section class="author__profile__banner__section">
        <div class="container">
            <div class="author__profile__banner urdu [ d-flex mobile-flex-wrap ]">
                <div class="author__profile__banner__image">
                    <img src="{{ URL::asset('storage/profile_photo/' . $users->profile_photo) }}" alt="Author Image" />
                </div>
                <div class="author__profile__banner__content">
                    <h2 class="fs-1 fw-bold mb-4 author__name">{{$users->name}}</h2>
                    <p class="author__discription mb-0">
                    <p>{!! Illuminate\Support\Str::limit($users->about_us, 300)!!}</p>

                     
                      
                    </p>
                    <ul class="social__links [ d-flex align-items-center gap-2 ]">
                        <li><a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li><a href="https://www.youtube.com/"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="https://twitter.com/i/flow/login"><i class="fa-brands fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    {{-- {{$categorylists}} --}}
    <section class="author__tab__header__section mb-5">
        <ul class="author__tab__header">

            <li id="tab-1" class="custom__tab author__tab__header__item">All Posts ({{ $authorlistcount }})</li>
            <li id="tab-2" class="custom__tab author__tab__header__item active">About Author</li>
            <li id="tab-3" class="custom__tab author__tab__header__item {{($authorbookcount=='0') ? 'activee' : 'blocks'}}">Books ({{ $authorbookcount }})</li>
            @php
                $i = 4;
            @endphp
            @foreach ($categorylis as $categoryli)
                <li id="tab-{{ $i++ }}" class="custom__tab author__tab__header__item ">{{ $categoryli->name }}
                    ({{ count($categoryli->articals) }})</li>
            @endforeach
            {{--      <li id="tab-4" class="custom__tab author__tab__header__item">Hamd (5)</li>
     <li id="tab-6" class="custom__tab author__tab__header__item">Naat Shareef (5)</li>
      <li id="tab-7" class="custom__tab author__tab__header__item">Manqabat (5)</li> --}}

        </ul>
    </section>
    <section class="author__tab__body">
        <div data-id="tab-1" class="author__tab__data custom__tab__data">
            <div class="container">
                <div class="section-heading [ d-flex align-items-center ]">
                    <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-2">
                        <span class="white-space-nowrap">All Posts (25)</span>
                    </h2>
                </div>

                <!-- Featured Articals -->
                {{-- <section class="post-section pb-md-5">
          <div class="row g-5 featured__articals__card__container horizontal__scroll">
            <div class="col-12 col-lg-6 col-xl-4">
              <div class="medium-cards-container">
                <div class="post-image">
                  <a href="./listing.php">
                    <img src="./assets/img/shot-by.jpg" alt="Image" />
                  </a>
                </div>
                <div class="post-content arabic [ d-flex flex-column justify-content-between ]">
                  <div class="post-auth-date [ d-flex ]">
                    <ul class="d-flex">
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-user"></i>
                          Author Name
                        </a>
                      </li>
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-calendar"></i>
                          Jan 20, 2022
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <div class="post-tags mb-md-4 mb-4">
                      <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                    </div>
                    <a href="./listing.php">
                      <h3 class="m-0 post-heading">
                        قدم إلي فضيلة الشيخ عبداللطيف خلف عبد اللطيف فرغلي المبعوث من الأزهر الشريف درع تكريمي
                      </h3>
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-6 col-xl-4">
              <div class="medium-cards-container">
                <div class="post-image">
                  <a href="./post-details.php">
                    <img src="./assets/img/shot-by.jpg" alt="Image" />
                  </a>
                </div>
                <div class="post-content urdu [ d-flex flex-column justify-content-between ]">
                  <div class="post-auth-date [ d-flex ]">
                    <ul class="d-flex">
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-user"></i>
                          Author Name
                        </a>
                      </li>
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-calendar"></i>
                          Jan 20, 2022
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <div class="post-tags mb-md-4 mb-4">
                      <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                    </div>
                    <a href="./post-details.php">
                      <h3 class="m-0 post-heading">
                        جشن یوم غزالی کے موقع پر شیخ عبد القادر جیلانی اور خواجہ نظام الدین اولیا کا عرس
                      </h3>
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-12 col-lg-6 col-xl-4">
              <div class="medium-cards-container">
                <div class="post-image">
                  <a href="./post-details.php">
                    <img src="./assets/img/shot-by.jpg" alt="Image" />
                  </a>
                </div>
                <div class="post-content urdu [ d-flex flex-column justify-content-between ]">
                  <div class="post-auth-date [ d-flex ]">
                    <ul class="d-flex">
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-user"></i>
                          Author Name
                        </a>
                      </li>
                      <li>
                        <a href="javascript:;">
                          <i class="fa-solid fa-calendar"></i>
                          Jan 20, 2022
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <div class="post-tags mb-md-4 mb-4">
                      <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                    </div>
                    <a href="./post-details.php">
                      <h3 class="m-0 post-heading">
                        جشن یوم غزالی کے موقع پر شیخ عبد القادر جیلانی اور خواجہ نظام الدین اولیا کا عرس
                      </h3>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section> --}}
                <section class="post-section py-md-5 mt-4">
                    <div class="container">
                        <div class="row g-5">




                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="medium-cards-container">
                                    <div class="post-image">
                                        <a href="javascript:void(0)">

                                            <img src="{{ URL::asset('storage/profile_photo/' . $users->profile_photo) }}"
                                                alt="image">

                                        </a>
                                    </div>
                                    <div class="post-content arabic [ d-flex flex-column justify-content-between ]">
                                        <div class="post-auth-date [ d-flex ]">
                                            <ul class="d-flex">
                                                <li>
                                                    <a href="javascript:;">
                                                        <i class="fa-solid fa-user"></i>
                                                        {{ $users->name }}
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;">
                                                        <i class="fa-solid fa-calendar"></i>
                                                        {{ Carbon\Carbon::parse($users->created_at)->format('d/m/Y') }}
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div>
                                            <div class="post-tags mb-md-4 mb-4">
                                                <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                                            </div>
                                            <a href="javascript:void(0)">
                                                <h3 class="m-0 post-heading">
                                                    test
                                                </h3>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </section>

                <div class="row g-5">
                    @foreach ($authorlistingalls as $authorlistingall)
                        <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                            <div class="post__listing__card">
                                <div class="post__listing__card__image">
                                    <ul class="__tags">
                                        <li><a href="javascript:;" class="btn btn-sm btn-primary tag">Fiqh-o-Hadeth</a></li>
                                    </ul>
                                    <a href="javascript:;">
                                        <img src="{{ URL::asset('storage/articals/' . $authorlistingall->image) }}"
                                            alt="Listing Image">
                                    </a>
                                </div>
                                <div class="post__listing__card__content urdu">
                                    <a href="{{ route('articals', $authorlistingall->url) }}">
                                        <h4 class="mb-3 fw-bold">{{ $authorlistingall->title }}</h4>
                                    </a>
                                    <p>{!! Str::words(strip_tags($authorlistingall->content, 20)) !!}</p>
                                    <ul class="post-auth-date d-flex font-roboto mt-4">
                                        <li>
                                            <a href="javascript:;">
                                                <i class="fa-solid fa-user"></i>
                                                {{ $authorlistingall->user->name??null }}
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <i class="fa-solid fa-calendar"></i>
                                                {{ Carbon\Carbon::parse($authorlistingall->created_at)->format('d/m/Y') }}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endforeach


                </div>
                <div class="pagination__container w-100 d-flex justify-content-center my-5 pt-3">
                    <ul class="pagination pagination-lg">
                        {{ $authorlistingalls->links('pagination::bootstrap-4') }}
                        {{-- <li class="page-item"><a class="page-link" href="#">Previous</a></li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li> --}}
                    </ul>
                </div>
            </div>
        </div>
        <div data-id="tab-2" class="author__tab__data active">
            <div class="container">
                <div class="section-heading [ d-flex align-items-center ]">
                    <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-2">
                        <span class="white-space-nowrap">Author Profile</span>
                    </h2>
                </div>
                <div class="author__profile__container urdu [ d-flex flex-column mb-3 ]">
                    <div class="content__block">
                        <div class="content__block__text [ d-flex gap-md-5 gap-3 mobile-flex-wrap ]">
                            <p>
                            <p> {!!Str::words(strip_tags($users->about_us))!!}</p>
                          
                            </p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <div data-id="tab-3" class="author__tab__data ">
            <div class="container">
                <div class="section-heading [ d-flex align-items-center ]">
                    <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-2">
                        <span class="white-space-nowrap">Books ({{ $authorbookcount }})</span>
                    </h2>
                </div>
                <div class="books__section mb-5">
                    <div class="row g-5">
                        @foreach ($authorbooks as $authorbook)
                            <div class="col-12 col-md-6 col-lg-4 col-xxl-3">
                                <div class="book__short__card">
                                    <div class="book__short__card__image">
                                        <a href="{{ route('book_details', $authorbook->url) }}">
                                            <img src="{{ asset('storage/book_image/' . $authorbook->book_image) }}"
                                                alt="Book Mockup" />
                                        </a>
                                    </div>
                                    <div class="book__short__card__content urdu">
                                        <h3> {{ $authorbook->title }}</h3>
                                    </div>
                                </div>
                            </div>
                        @endforeach

                    </div>
                </div>
            </div>
        </div>
        @php
            $i = 4;
        @endphp

        @foreach ($categorylis as $categoryl)
            <div data-id="tab-{{ $i++ }}" class="author__tab__data">
                <div class="container">
                    <div class="section-heading [ d-flex align-items-center ]">
                        <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-2">
                            <span class="white-space-nowrap">{{ $categoryl->name }}
                                ({{ count($categoryl->articals) }})</span>
                        </h2>

                    </div>
                    <div class="row g-5">
                     @foreach ($categoryl->articals as $artical)
                     <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                            <div class="post__listing__card">
                                <div class="post__listing__card__image">
                                    <ul class="__tags">
                                        <li><a href="{{ route('articals',$artical->url)}}" class="btn btn-sm btn-primary tag">Fiqh-o-Hadeth</a>
                                        </li>
                                    </ul>
                                    <a href="{{ route('articals',$artical->url)}}">
                                          <img src="{{ URL::asset('storage/articals/' . $artical->image) }}" alt="">
                                    </a>
                                </div>
                                <div class="post__listing__card__content urdu">
                                    <a href="{{ route('articals',$artical->url)}}">
                                        <h4 class="mb-3 fw-bold">{{$artical->title}}</h4>
                                    </a>
                                     
                                    <p> {!!Str::words(strip_tags($artical->content, 20))!!}</p>
                                    <ul class="post-auth-date d-flex font-roboto mt-4">
                                        <li>
                                            <a href="{{ route('articals',$artical->url)}}">
                                                <i class="fa-solid fa-user"></i>
                                                {{$artical->user->name??null}}
                                            </a>
                                        </li>
                                        <li>
                                            <a href="{{ route('articals',$artical->url)}}">
                                                <i class="fa-solid fa-calendar"></i>
                                               {{ Carbon\Carbon::parse($artical->created_at)->format('d/m/Y') }}
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        @endforeach

                        
                   </div>
                </div>
            </div>
        @endforeach


    </section>

    <section class="post-section">
        <div class="container">
            <div class="ad__cont horizontal">
                <a href="javascript:void(0)">
                    <i class="fa-solid fa-ad"></i>
                    <picture>
                        <!-- <source media="(max-width:650px)" srcset="img_pink_flowers.jpg">
              <source media="(max-width:465px)" srcset="img_white_flower.jpg"> -->
                        <img src="https://www.famousmuslimastrologer.com/wp-content/themes/blankslate/images/header_inner.jpg"
                            alt="Ad Image">
                    </picture>
                </a>
            </div>
        </div>
    </section>
     @php
     $mostviews = App\Models\Artical::with('user')->orderBy('viewd', 'desc')->limit(5)->get();
    @endphp
    <section class="post-section py-md-5">
        <div class="container">
            <div class="section-heading [ d-flex align-items-center ]">
                <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-1">
                    <span class="white-space-nowrap">Most Popular Articals</span>
                </h2>
                <a href="{{ route('allartical') }}" class="white-space-nowrap [ btn btn-light border hover-dark ]">
                    View All
                    <i class="fa-solid fa-long-arrow-right"></i>
                </a>
            </div>
            <div class="row g-5">
                <div class="col-12 col-lg-12 col-xl-3">
                    <div class="ad__cont vertical">
                        <a href="javascript:void(0)">
                            <i class="fa-solid fa-ad"></i>
                            <picture>
                              
                                <img src="{{ asset('frontend/assets/img/ad.jpg') }}" alt="Ad Image">
                            </picture>
                        </a>
                    </div>
                </div>
                <div class="col-12 col-lg-12 col-xl-9">
                    <div class="row g-5">
                        <div class="col-12 col-lg-7">
                            <div class="row g-5 mobile__scroll">
                                  @forelse($mostviews as $key=> $artical)
                              
                                @if($key<3)

                                <div class="col-12">
                                    <div class="small-cards-container">
                                        <div class="post-content {{($artical->language_id=='3') ? 'urdu' : 'hindi'}} [ d-flex justify-content-between flex-column  ]">
                                            <a href="{{ route('articals',$artical->url)}}">
                                          <h4>{{$artical->title}}</h4>
                                            </a>
                                            <div class="post-auth-date [ d-flex ]">
                                                <ul class="d-flex">
                                                    <li>
                                                        <a href="{{ route('articals',$artical->url)}}">
                                                            <i class="fa-solid fa-user"></i>
                                                             {{$artical->user->name??null}}
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="{{ route('articals',$artical->url)}}">
                                                            <i class="fa-solid fa-calendar"></i>
                                                            {{ Carbon\Carbon::parse($artical->created_at)->format('d/m/Y') }}
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="post-image">
                                            <div class="post-tags [ d-flex gap-2 ]">
                                                <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                                            </div>
                                            <a href="javascript:void(0)">
                                                <img src="{{ URL::asset('storage/articals/' . $artical->image) }}" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                   @endif
                            
                             
                             @empty  
                          <p class="bg-danger text-white p-1">no artical</p>  
                           @endforelse 

                            </div>
                        </div>
                        <div class="col-12 col-lg-5">
                            <div class="medium-cards-container">
                                <div class="post-image">
                                    <a href="javascript:void(0)">
                                        <img src="{{ URL::asset('storage/articals/' . @$mostviews[0]->image) }}" alt="Image" />
                                    </a>
                                </div>
                                <div class="post-content hindi [ d-flex flex-column justify-content-between ]">
                                    <div class="post-auth-date [ d-flex ]">
                                        <ul class="d-flex">
                                            <li>
                                                <a href="javascript:;">
                                                    <i class="fa-solid fa-user"></i>
                                                   {{@$mostviews[0]->user->name??null}}
                                                </a>
                                            </li>
                                            <li>
                                                <a href="javascript:;">
                                                    <i class="fa-solid fa-calendar"></i>
                                                    {{ Carbon\Carbon::parse(@$mostviews[0]->created_at)->format('d/m/Y') }}
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div>
                                        <div class="post-tags mb-md-4 mb-4">
                                            <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                                        </div>
                                        <a href="javascript:void(0)">
                                            <h3 class="m-0 post-heading">
                                           {{@$mostviews[0]->artical[0]->title}}
                                            </h3>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="row g-5 mobile__scroll">
                        
                        @forelse ($mostviews as $key=> $artical)  
                     

                       
                       @if(3<=$key ||$key >=5)
                        <div class="col-12 col-lg-6">
                       
                            <div class="small-cards-container">
                                <div class="post-content {{($artical->language_id=='3') ? 'urdu' : 'hindi'}} [ d-flex justify-content-between flex-column  ]">
                                   <a href="{{ route('articals',$artical->url)}}">
                                          <h4>{{$artical->title}}</h4>
                                    </a>

                                    <div class="post-auth-date [ d-flex ]">
                                        <ul class="d-flex">
                                            <li>
                                             <a href="{{ route('articals',$artical->url)}}">
                                                            <i class="fa-solid fa-user"></i>
                                                             {{$artical->user->name??null}}
                                                        </a>
                                            </li>
                                            <li>
                                                <a href="{{ route('articals',$artical->url)}}">
                                                            <i class="fa-solid fa-calendar"></i>
                                                            {{ Carbon\Carbon::parse($artical->created_at)->format('d/m/Y') }}
                                                        </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="post-image">
                                    <div class="post-tags [ d-flex gap-2 ]">
                                        <a href="{{ route('articals',$artical->url)}}" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                                    </div>
                                     <a href="{{ route('articals',$artical->url)}}">
                                      <img src="{{ URL::asset('storage/articals/' . $artical->image) }}" alt="">
                                      </a>
                                </div>
                            </div>
                        </div>
                          @endif
                         
                         
                             @empty  
        <p class="bg-danger text-white p-1"></p>  
    @endforelse
                         
                    </div>
                </div>
            </div>
        </div>
    </section>
 
@endsection
