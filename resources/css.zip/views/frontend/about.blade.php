@extends('frontend.includes.main')
 
@section('content')

 <!-- Hero Banner -->
  <section class="hero__banner__section __dark" style="background-image: url({{('frontend/assets/img/jamia-hero-banner.jpg')}}">
    <div class="container">
      <div class="hero__banner">
        <h3 class="font-gilroy-bold mb-3 fs-1">About</h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="./">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About</li>
          </ol>
        </nav>
      </div>
    </div>
  </section>

  <section class="about__page__section py-md-5 py-2">
    <div class="container mt-5">
      <div class="about__page__container mb-4 mb-md-0">
        <div class="about__page__content">
          <div class="text-center">
            <div class="media__logo mb-5">
              <img src="{{('frontend/assets/img/top-logo.svg')}}" alt="Media Logo" />
            </div>
            <h1 class="font-gilroy-bold text-primary text-uppercase">Al-Ehsan Media</h1>
          </div>
          <hr class="my-md-5 my-4" />
          <div class="d-flex flex-column gap-3">
            <div class="content__block">
              <h3 class="mb-3">{{$about->title}}</h3>
              <div class="content__block__text [ d-flex gap-md-5 gap-3 mobile-flex-wrap ]">
              {!!$about->content!!}
               
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </section>

   <section class="post-section">
    <div class="container">
      <div class="ad__cont horizontal">
        <a href="javascript:void(0)">
          <i class="fa-solid fa-ad"></i>
          <picture>
            <!-- <source media="(max-width:650px)" srcset="img_pink_flowers.jpg">
            <source media="(max-width:465px)" srcset="img_white_flower.jpg"> -->
            <img src="https://www.famousmuslimastrologer.com/wp-content/themes/blankslate/images/header_inner.jpg" alt="Ad Image">
          </picture>
        </a>
      </div>
    </div>
  </section>

  {{-- <section class="post-section py-md-5">
  <div class="container">
    <div class="section-heading [ d-flex align-items-center ]">
      <h2 class="heading-text m-0 font-gilroy-bold text-primary fs-1">
        <span class="white-space-nowrap">Most Popular Articals</span>
      </h2>
      <a href="javasript:;" class="white-space-nowrap [ btn btn-light border hover-dark ]">
        View All 
        <i class="fa-solid fa-long-arrow-right"></i>
      </a>
    </div>
    <div class="row g-5">        
      <div class="col-12 col-lg-12 col-xl-3">
        <div class="ad__cont vertical">
          <a href="javascript:void(0)">
            <i class="fa-solid fa-ad"></i>
            <picture>
              <!-- <source media="(max-width:650px)" srcset="img_pink_flowers.jpg">
              <source media="(max-width:465px)" srcset="img_white_flower.jpg"> -->
              <img src="{{asset('frontend/assets/img/ad.jpg')}}" alt="Ad Image">
            </picture>
          </a>
        </div>
      </div>
      <div class="col-12 col-lg-12 col-xl-9">
        <div class="row g-5">
          <div class="col-12 col-lg-7">
            <div class="row g-5 mobile__scroll">
              <div class="col-12">
                <div class="small-cards-container">
                  <div class="post-content hindi [ d-flex justify-content-between flex-column  ]">
                    <a href="javascript:void(0)">
                      <h4>मशाइखे चिश्त ने हमेशा हिन्दुस्तानी मिज़ाज की रियायत की है</h4>
                    </a>
                    <div class="post-auth-date [ d-flex ]">
                      <ul class="d-flex">
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-user"></i>
                            Author Name
                          </a>
                        </li>
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-calendar"></i>
                            Jan 20, 2022
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="post-image">
                    <div class="post-tags [ d-flex gap-2 ]">
                      <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                    </div>
                    <a href="javascript:void(0)">
                      <img src="{{asset('frontend/assets/img/slide-1.png')}}" alt="">
                    </a>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="small-cards-container">
                  <div class="post-content hindi [ d-flex justify-content-between flex-column  ]">
                    <a href="javascript:void(0)">
                      <h4>मशाइखे चिश्त ने हमेशा हिन्दुस्तानी मिज़ाज की रियायत की है</h4>
                    </a>
                    <div class="post-auth-date [ d-flex ]">
                      <ul class="d-flex">
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-user"></i>
                            Author Name
                          </a>
                        </li>
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-calendar"></i>
                            Jan 20, 2022
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="post-image">
                    <div class="post-tags [ d-flex gap-2 ]">
                      <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                    </div>
                    <a href="javascript:void(0)">
                      <img src="{{asset('frontend/assets/img/slide-1.png')}}" alt="">
                    </a>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="small-cards-container">
                  <div class="post-content hindi [ d-flex justify-content-between flex-column  ]">
                    <a href="javascript:void(0)">
                      <h4>मशाइखे चिश्त ने हमेशा हिन्दुस्तानी मिज़ाज की रियायत की है</h4>
                    </a>
                    <div class="post-auth-date [ d-flex ]">
                      <ul class="d-flex">
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-user"></i>
                            Author Name
                          </a>
                        </li>
                        <li>
                          <a href="javascript:;">
                            <i class="fa-solid fa-calendar"></i>
                            Jan 20, 2022
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="post-image">
                    <div class="post-tags [ d-flex gap-2 ]">
                      <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                    </div>
                    <a href="javascript:void(0)">
                      <img src="{{asset('frontend/assets/img/slide-1.png')}}" alt="">
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-5">
            <div class="medium-cards-container">
              <div class="post-image">
                <a href="javascript:void(0)">
                  <img src="{{asset('frontend/assets/img/shot-by.jpg')}}" alt="Image" />
                </a>
              </div>
              <div class="post-content hindi [ d-flex flex-column justify-content-between ]">
                <div class="post-auth-date [ d-flex ]">
                  <ul class="d-flex">
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-user"></i>
                        Author Name
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-calendar"></i>
                        Jan 20, 2022
                      </a>
                    </li>
                  </ul>
                </div>
                <div>
                  <div class="post-tags mb-md-4 mb-4">
                    <a href="javascript:;" class="btn btn-primary tag">Fiqh-o-Hadeth</a>
                  </div>
                  <a href="javascript:void(0)">
                    <h3 class="m-0 post-heading">
                      न्याय के बिना समाज में अमन व शाँति कायम नहीं हो सकती । उबैदुल्लाह खान आज़मी
                    </h3>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12">
        <div class="row g-5 mobile__scroll">
          <div class="col-12 col-lg-6">
            <div class="small-cards-container">
              <div class="post-content hindi [ d-flex justify-content-between flex-column  ]">
                <a href="javascript:void(0)">
                  <h4>मशाइखे चिश्त ने हमेशा हिन्दुस्तानी मिज़ाज की रियायत की है</h4>
                </a>
                <div class="post-auth-date [ d-flex ]">
                  <ul class="d-flex">
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-user"></i>
                        Author Name
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-calendar"></i>
                        Jan 20, 2022
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="post-image">
                <div class="post-tags [ d-flex gap-2 ]">
                  <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                </div>
                <a href="javascript:void(0)">
                  <img src="{{asset('frontend/assets/img/slide-1.png')}}" alt="">
                </a>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-6">
            <div class="small-cards-container">
              <div class="post-content hindi [ d-flex justify-content-between flex-column  ]">
                <a href="javascript:void(0)">
                  <h4>मशाइखे चिश्त ने हमेशा हिन्दुस्तानी मिज़ाज की रियायत की है</h4>
                </a>
                <div class="post-auth-date [ d-flex ]">
                  <ul class="d-flex">
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-user"></i>
                        Author Name
                      </a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa-solid fa-calendar"></i>
                        Jan 20, 2022
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="post-image">
                <div class="post-tags [ d-flex gap-2 ]">
                  <a href="javasript:;" class="btn btn-primary btn-sm">Fiqh-o-Hadeeth</a>
                </div>
                <a href="javascript:void(0)">
                  <img src="{{asset('frontend/assets/img/slide-1.png')}}" alt="">
                </a>
              </div>
            </div>
          </div>    
        </div>
      </div>
    </div>
  </div>
</section> --}}



@endsection