@extends('frontend.includes.main')

@section('content')
    <section class="breadcrumb__section py-4">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 breadcrumb-post-details">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item"><a href="./">Artical</a></li>
                    <li class="breadcrumb-item"><a href="./">{{ $articaldetails->category->name }}</a></li>
                    <li class="breadcrumb-item active {{ $articaldetails->language_id == '3' ? 'urdu' : 'hindi' }}"
                        aria-current="page">{{ $articaldetails->title }}</li>
                </ol>
            </nav>
        </div>
    </section>
    <!-- Banner and content -->
    <section class="post__content__section">
        <div class="container">
            <div class="post__banner">
                <picture>
                    <!-- <source media="(max-width:650px)" srcset="img_pink_flowers.jpg"> -->

                    <img src="{{ URL::asset('storage/articals/' . $articaldetails->image) }}"
                        alt="{{ $articaldetails->title }}">
                </picture>
                <div class="post__tags [ d-flex gap-3 flex-wrap align-items-center ]">
                    <a class="btn btn-primary">Hindi News</a>
                    <a class="btn btn-primary">Fiqh-o-Hadeeth</a>
                </div>
            </div>
            <div class="post__content pt-md-4 pt-lg-5 pt-3">
                <div class="post__content__header mb-4">
                    <h1 class="fw-bold mb-4">{{ $articaldetails->title }}</h1>
                    <div
                        class="post__info [ d-flex flex-wrap gap-2 justify-content-between border-top border-bottom py-2 ]">
                        <ul class="post__info__list">
                            <li>
                                <a href="javascript:;">
                                    <i class="fa-solid fa-user"></i>
                                    <span>{{ $articaldetails->user->name??null }}</span>
                                </a>
                            </li>
                            <li>
                                <i class="fa-solid fa-calendar"></i>
                                <span>{{ Carbon\Carbon::parse($articaldetails->created_at)->format('d/m/Y') }}</span>
                            </li>
                        </ul>
                        <div class="[ d-flex gap-2 ]">
                            <ul class="post__info__list">
                                <li>
                                    <i class="fa-solid fa-eye"></i>
                                    <span>{{ $articaldetails->viewd }}</span>
                                </li>
                                <li>
                                    <i class="fa-solid fa-comments"></i>
                                    <span>{{ count($articaldetails->comment) }}</span>
                                </li>
                                <li class="countbtnshare" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                    <input type="hidden" name="name" id="artical_iddd" value="{{ $articaldetails->id }}"/>
                                    <i class="fa-solid fa-share-from-square"></i>
                                    <span> {{ $articaldetails->shared }}</span>
                                    {{-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
 
</button> --}}

                                </li>
                            </ul>

                        </div>
                    </div>
                </div>
                <div class="post__content__body {{ $articaldetails->language_id == '3' ? 'urdu' : 'hindi' }}">
                    {!! $articaldetails->content !!}
                </div>
            </div>
            {{-- <div class="comment__box">
        <h3>Comment Plughin</h3>
        
      </div> --}}
            <div class="col-lg-8">
                <div class="single-post__comment">
                    <div class="widget__title">
                        <h4>({{ count($articaldetails->comment) }}) Comment</h4>
                    </div>
                </div>
                @foreach ($articaldetails->comment as $comment)
                    <div class="single-post__author__profile">
                        <div class="single-post__author__profile__pic">
                            <img src="{{ asset('frontend/assets/img/avatar.png') }}" alt="">
                        </div>
                        <div class="single-post__author__profile__text">
                            <h4>{{ $comment->name }}.</h4>
                            <p>{{ $comment->message }}</p>

                        </div>
                    </div>
                @endforeach

                <div class="single-post__leave__comment login__form__block__input__box ">
                    <div class="widget__title">
                        <h4>Leave a comment</h4>
                    </div>
                    <form action="{{ route('comment_post') }}" method="post">
                        @csrf

                        <div class="input-list">
                            <i class="fa fa-user fa-lg"></i>
                            <input type="text" name="name" placeholder="Name" required>
                            <i class="fa-solid fa-envelope fa-lg"></i>
                            <input type="text" name="email" placeholder="Email" required>
                            <i class="fa-solid fa-phone fa-lg"></i>
                            <input type="text" name="phone" placeholder="Phone">
                            <input type="hidden" name="artical_id" value="{{ $articaldetails->id }}">
                        </div>


                        <i class="fa-solid fa-envelope-open-text"></i>
                        <textarea placeholder="Message" name="message"></textarea>
                        <button type="submit" class="btn btn-lg btn-secondary d-inline-flex gap-x-3 align-items-center"
                            fdprocessedid="i9irrk">
                            Submit
                            <i class="fa-solid fa-paper-plane"></i>
                        </button>

                    </form>

                </div>

            </div>
        </div>
    </section>

    <section class="related__articals__section mb-5">
        <div class="container">
            <div class="col-12">
                <div class="section-heading [ d-flex align-items-center mb-5 ]">
                    <h2 class="heading-text borderless m-0 font-gilroy-bold text-white fs-1">
                        <span>
                            <span class="font-gilroy-light">Related</span>
                            <span class="font-gilroy-bold">Articals</span>
                        </span>
                    </h2>
                </div>
            </div>
            <div class="row g-5 featured__articals__card__container horizontal__scroll">
                @foreach ($relatedarticals as $relatedartical)
                    <div class="col-12 col-md-6 col-lg-4 col-xxl-3 d-flex">
                        <div class="post__listing__card light">
                            <div class="post__listing__card__image">
                                <ul class="__tags">
                                    <li><a href="{{ route('articals', $relatedartical->url) }}"
                                            class="btn btn-sm btn-primary tag">Fiqh-o-Hadeth</a></li>
                                </ul>
                                <a href="javascript:;">
                                    <img src="{{ URL::asset('storage/articals/' . $relatedartical->image) }}"
                                        alt="">
                                </a>
                            </div>
                            <div class="post__listing__card__content urdu">
                                <a href="{{ route('articals', $relatedartical->url) }}">
                                    <h4 class="mb-3 fw-bold">{{ $relatedartical->title }}</h4>
                                </a>
                                <p> {!! Str::words(strip_tags($relatedartical->content, 10)) !!}</p>
                                <ul class="post-auth-date d-flex font-roboto mt-4">
                                    <li>
                                        <a href="javascript:;">
                                            <i class="fa-solid fa-user"></i>
                                            {{ $relatedartical->user->name??null }}
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <i class="fa-solid fa-calendar"></i>
                                            {{ Carbon\Carbon::parse($relatedartical->created_at)->format('d/m/Y') }}
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

   
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="_12kfhdn">
                        <section class="justify-content-center">
                            <h2 tabindex="-1" class="_14i3z6h" elementtiming="LCP-target">
                                <div class="_e0px5r">Share this place</div>
                            </h2>
                           
                            <div class="_1byskwn">
                                 <div class="_9zsv75f">
                               {!! $shareComponent !!}

                                {{-- <div class="_9zsv75f">
                                    <div class="_mnf8sq"><button role="link" type="button"
                                            class="l1j9v1wn bbkw4bl c1rxa9od dir dir-ltr">
                                            <div class="_5kaapu">
                                                <div class="_1l9dusq"><svg viewBox="0 0 32 32"
                                                        xmlns="http://www.w3.org/2000/svg" aria-hidden="true"
                                                        role="presentation" focusable="false"
                                                        style="display: block; height: 32px; width: 32px;">
                                                        <path d="m32 0v32h-32v-32z" fill="#25d366"></path>
                                                        <path
                                                            d="m4 28 1.695-6.163a11.824 11.824 0 0 1 -1.595-5.946c.003-6.556 5.364-11.891 11.95-11.891a11.903 11.903 0 0 1 8.453 3.488 11.794 11.794 0 0 1 3.497 8.414c-.003 6.557-5.363 11.892-11.95 11.892-2 0-3.97-.5-5.715-1.448zm6.628-3.807c1.684.995 3.292 1.591 5.418 1.592 5.474 0 9.933-4.434 9.936-9.885.002-5.462-4.436-9.89-9.928-9.892-5.478 0-9.934 4.434-9.936 9.884 0 2.225.654 3.891 1.754 5.634l-1.002 3.648 3.76-.98h-.002zm11.364-5.518c-.074-.123-.272-.196-.57-.344-.296-.148-1.754-.863-2.027-.96-.271-.1-.469-.149-.667.147-.198.295-.767.96-.94 1.157s-.346.222-.643.074c-.296-.148-1.253-.46-2.386-1.466-.881-.783-1.477-1.75-1.65-2.045s-.018-.455.13-.602c.134-.133.296-.345.445-.518.15-.17.2-.294.3-.492.098-.197.05-.37-.025-.518-.075-.147-.668-1.6-.915-2.19-.241-.577-.486-.499-.668-.508l-.569-.01a1.09 1.09 0 0 0 -.79.37c-.272.296-1.039 1.01-1.039 2.463s1.064 2.857 1.211 3.054c.15.197 2.092 3.18 5.068 4.458.708.304 1.26.486 1.69.622.712.224 1.359.193 1.87.117.57-.084 1.755-.714 2.002-1.404.248-.69.248-1.28.173-1.405z"
                                                            fill="#FFF"></path>
                                                    </svg></div>
                                                <div class="_1xzp9wc">WhatsApp</div>
                                            </div>
                                        </button></div>
                                </div>
                                
                                <div class="_9zsv75f">
                                    <div class="_mnf8sq"><button role="link" type="button"
                                            class="l1j9v1wn bbkw4bl c1rxa9od dir dir-ltr">
                                            <div class="_5kaapu">
                                                <div class="_1l9dusq"><svg viewBox="0 0 32 32"
                                                        xmlns="http://www.w3.org/2000/svg" aria-hidden="true"
                                                        role="presentation" focusable="false"
                                                        style="display: block; height: 32px; width: 32px;">
                                                        <path fill="#1877F2" d="M32 0v32H0V0z"></path>
                                                        <path
                                                            d="M22.938 16H18.5v-3.001c0-1.266.62-2.499 2.607-2.499h2.018V6.562s-1.831-.312-3.582-.312c-3.654 0-6.043 2.215-6.043 6.225V16H9.436v4.625H13.5V32h5V20.625h3.727l.71-4.625z"
                                                            fill="#FFF"></path>
                                                    </svg></div>
                                                <div class="_1xzp9wc">Facebook</div>
                                            </div>
                                        </button></div>
                                </div>
                                <div class="_9zsv75f">
                                    <div class="_mnf8sq"><button role="link" type="button"
                                            class="l1j9v1wn bbkw4bl c1rxa9od dir dir-ltr">
                                            <div class="_5kaapu">
                                                <div class="_1l9dusq"><svg viewBox="0 0 32 32"
                                                        xmlns="http://www.w3.org/2000/svg" aria-hidden="true"
                                                        role="presentation" focusable="false"
                                                        style="display: block; height: 32px; width: 32px;">
                                                        <path fill="#1DA1F2" d="M0 0H32V32H0z"></path>
                                                        <path
                                                            d="M18.664 7.985a4.5 4.5 0 0 0-2.289 4.89c-3.5-.188-6.875-1.813-9.063-4.625a4.25 4.25 0 0 0 1.375 5.875c-.687 0-1.374-.125-2-.438.063 2.063 1.5 3.876 3.5 4.313-.624.188-1.312.188-2 .063.626 1.812 2.313 3.062 4.188 3.125-1.813 1.5-4.25 2.187-6.563 1.812a12.438 12.438 0 0 0 19.313-11.188c.875-.624 1.625-1.374 2.188-2.312-.75.375-1.625.625-2.5.75.937-.563 1.625-1.438 2-2.5-.875.5-1.813.875-2.813 1.063a4.5 4.5 0 0 0-5.336-.828z"
                                                            fill="#FFF"></path>
                                                    </svg></div>
                                                <div class="_1xzp9wc">Twitter</div>
                                            </div>
                                        </button></div>
                                </div> --}}
                                
                            </div>
                        </section>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
@endsection
