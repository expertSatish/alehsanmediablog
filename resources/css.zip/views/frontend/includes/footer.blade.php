<footer>
  <div class="footer-nav-container" id="footer">
    <div class="container">
      <div class="foter-top-menu [ d-flex align-items-center justify-content-between ]">
        <ul class="menu [ d-flex ]">
          <li>
            <a href="{{ route('aboutusdd') }}">Abuot us</a>
          </li>
          <li>
            <a href="{{ url('contact') }}">Contact Us</a>
          </li>
          <li>
            <a href="{{ route('register') }}">Register as an Author</a>
          </li>
          <li>
            <a href="{{ route('privacypolicydd') }}">Privacy Policy</a>
          </li>
          <li>
            <a href="{{ route('termsconditionsdd') }}">Terms & Conditions</a>
          </li>
        </ul>
        <ul class="social [ d-flex ]">
          <li class="icon">
            <a href="https://www.facebook.com/AlehsanMedia"  target="_blank">
              <i class="fa-brands fa-facebook-f"></i>
            </a>
          </li>
          <li class="icon">
            <a href=" https://www.youtube.com/@AlehsanMediaOfficial"  target="_blank">
              <i class="fa-brands fa-youtube"></i>
            </a>
          </li>
          <li class="icon">
            <a href="https://www.instagram.com/alehsanmedia"  target="_blank">
              <i class="fa-brands fa-instagram"></i>
            </a>
          </li>
          <li class="icon">
            <a href="https://twitter.com/alehsanmedia"  target="_blank">
              <i class="fa-brands fa-twitter"></i>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row g-5">
      <div class="col-12 col-lg-8">
        <div class="row g-5">
          <div class="col-12 col-lg-6">
            <div class="footer-content">
              <img src="{{asset('frontend/assets/img/top-logo.svg')}}" alt="Footer Logo" class="mb-4" width="120" />
              <br />
              <p class="pe-md-5">
              @php 
               $about = App\Models\About::where('id',1)->first();
              @endphp
              {!!Str::words($about->content, 30)!!}
                
              </p>
              <a href="{{ route('aboutusdd') }}" class="btn border btn-outline-light mt-3 opacity-75">Read More</a>
            </div>
          </div>
          <div class="col-12 col-lg-6">
            <div class="footer-subscribe-container">
              <h3 class="font-poppins fw-medium text-light my-4">Indulge Yourself</h3>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod tenetur asperiores nobis ut esse eum vitae fugit consequuntur. Qui, laudantium.
              </p>

            
              <form action="{{ route('subscribe_us_post') }}" class="mt-4" method="post">
                @csrf
                <div class="form-group d-flex flex-column justify-content-start align-items-start gap-4">
                  <input type="text" name="email" class="form-control form-control-lg" placeholder="Enter your email id" />
                  <button type="submit" class="btn btn-secondary btn-lg" id="#btnClick">
                    Subscribe Now
                    <i class="fa-solid fa-long-arrow-right"></i>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-lg-4 ps-lg-4">
        <div class="print_n_digital_container" style="background-image: url(https://images.news18.com/ibnlive/uploads/2021/08/1628438277_islamic-new-year.jpg">
          <div class="content">
            <h3 class="font-poppins fw-bold">Print & Digital</h3>
            <p>Monthly home delivery, with free shipping of the print issues. Plus an exclusive access to the online archive on our E-Magazine edition!</p>
            <a href="javascript:;" type="button" class="btn btn-outline-warning">
              Subscribe
              <i class="fa-solid fa-long-arrow-right"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>


<script src="{{asset('frontend/assets/js/custome.js')}}"></script>
 {{-- <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> --}}
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


 
<script type="text/javascript">
var $j = jQuery.noConflict();
$j(function(){
     setTimeout(function() {
    $j('#successMessage').fadeOut('fast');
}, 3000); 
});

   
</script> 

<script>
var $j = jQuery.noConflict();
$j (function () {
$j('#btnClick') .click(function () {
$j ('html, body') .animate ({
scrollTop: $j(".footer") .offset().top + $j(".footer")[0].scrollHeight
}, 2000);
return false;
})
});
</script>
<script>
$j(document).on("click", ".countbtnshare", function(event) {


$j.ajaxSetup({
   headers: {
      'X-CSRF-TOKEN': $j('meta[name="csrf-token"]').attr('content')
   }
});

let formData = new FormData();
formData.append('_method', 'Post');
formData.append('artical_iddd', $j('#artical_iddd').val());

$j.ajax({
url: `{{ URL::to('share-link-count')}}`,
type: 'POST',
processData: false,
contentType: false,
dataType: 'json',
data: formData,
context: this,
success: function(result) {
if (result.success) {
//location.reload();
}
}
});

});
</script>
<script>
$j(document).on("click", ".countbtnsharevideo", function(event) {


$j.ajaxSetup({
   headers: {
      'X-CSRF-TOKEN': $j('meta[name="csrf-token"]').attr('content')
   }
});

let formData = new FormData();
formData.append('_method', 'Post');
formData.append('video_iddd', $j('#video_iddd').val());

$j.ajax({
url: `{{ URL::to('share-video-count')}}`,
type: 'POST',
processData: false,
contentType: false,
dataType: 'json',
data: formData,
context: this,
success: function(result) {
if (result.success) {
//location.reload();
}
}
});

});
</script>

<script>
$j(document).on("click", ".countbtnsharebook", function(event) {


$j.ajaxSetup({
   headers: {
      'X-CSRF-TOKEN': $j('meta[name="csrf-token"]').attr('content')
   }
});

let formData = new FormData();
formData.append('_method', 'Post');
formData.append('artical_iddd', $j('#book_iddd').val());

$j.ajax({
url: `{{ URL::to('share-book-count')}}`,
type: 'POST',
processData: false,
contentType: false,
dataType: 'json',
data: formData,
context: this,
success: function(result) {
if (result.success) {
//location.reload();
}
}
});

});
</script>