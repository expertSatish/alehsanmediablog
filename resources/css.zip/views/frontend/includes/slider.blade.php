  <!-- <section class="slider-section"> 
      <div class="slider-container container">
      <div class="slide container">
        <div class="content">
          <div class="contentflexEnd [ d-flex flex-column justify-content-between ]">
            <div class="content-wrapper"> 
              <div class="user">
                <span>Jan 20, 2017</span>
                <i class="fas fa-calendar-alt"></i>
              </div>
              <div class="user">
                <span>Author Name</span>
                <i class="fas fa-user"></i>
              </div>
            </div>
            <div class="content-heading">
              <a hef="#" class="btn btn-primary">Login</a>
              <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit</h3>
            </div>
          </div>
        </div>
      </div>
      <div class="slide container one">
        <div class="content">
          <div class="contentflexEnd [ d-flex flex-column justify-content-between ]">
            <div class="content-wrapper"> 
              <div class="user">
                <span>Jan 20, 2017</span>
                <i class="fas fa-calendar-alt"></i>
              </div>
              <div class="user">
                <span>Author Name</span>
                <i class="fas fa-user"></i>
              </div>
            </div>
            <div class="content-heading">
              <a hef="#" class="btn btn-primary">Login</a>
              <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit</h3>
            </div>
          </div>
        </div>
      </div>
      <div class="slide container">
        <div class="content">
          <div class="contentflexEnd [ d-flex flex-column justify-content-between ]">
            <div class="content-wrapper"> 
              <div class="user">
                <span>Jan 20, 2017</span>
                <i class="fas fa-calendar-alt"></i>
              </div>
              <div class="user">
                <span>Author Name</span>
                <i class="fas fa-user"></i>
              </div>
            </div>
            <div class="content-heading">
              <a hef="#" class="btn btn-primary">Login</a>
              <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit</h3>
            </div>
          </div>
        </div>
      </div>
      <div class="slide container">
        <div class="content">
          <div class="contentflexEnd [ d-flex flex-column justify-content-between ]">
            <div class="content-wrapper"> 
              <div class="user">
                <span>Jan 20, 2017</span>
                <i class="fas fa-calendar-alt"></i>
              </div>
              <div class="user">
                <span>Author Name</span>
                <i class="fas fa-user"></i>
              </div>
            </div>
            <div class="content-heading">
              <a hef="#" class="btn btn-primary">Login</a>
              <h3>Lorem ipsum dolor sit amet consectetur adipisicing elit</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

  <script>
    $('.slider-container').slick({
        infinite: true,
        speed: 300,
        arrow: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        // autoplay: true,
        autoplaySpeed: 2000,
    });
  </script> -->